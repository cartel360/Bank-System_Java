/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BankSystem;

/**
 *
 * @author d3cartel
 */
public class BankSystem {
    
    public static void main(String args[]){
        Loading ss = new Loading();
        ss.setVisible(true);
        try{
            for (int i = 0; i <= 100; i++){
                Thread.sleep(40);
                ss.lb1.setText(Integer.toString(i)+"%");
                BankSystemHome hh = new BankSystemHome();
                if (i == 100){
                    ss.dispose();
                    hh.show();
                }
            }
        } catch(Exception e){
            
        }
    }
    
}
